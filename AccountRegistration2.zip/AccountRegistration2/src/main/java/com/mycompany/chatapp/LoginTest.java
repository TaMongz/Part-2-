package com.mycompany.chatapp;

public class LoginTest {

    Login login = new Login();

    // A known-valid password/cellphone used when isolating the username check
    private static final String VALID_PASSWORD = "Ch&sec@ke99!";
    private static final String VALID_CELL = "+27838968976";

    //*** assertEquals: registration messages ***

    
    public void testUsernameCorrectlyFormatted() {
        // Test Data: "kyl_1"
        String result = login.registerUser("Kyle", "Smith", "kyl_1", VALID_PASSWORD, VALID_CELL);
        assertEquals("Username successfully captured. Password successfully captured. "
                + "Cell phone number successfully captured.", result);
    }

    
    public void testUsernameIncorrectlyFormatted() {
        // Test Data: "kyle!!!!!"
        String result = login.registerUser("Kyle", "Smith", "kyle!!!!!", VALID_PASSWORD, VALID_CELL);
        assertEquals("Username is not correctly formatted; please ensure that your username "
                + "contains an underscore and is no more than five characters in length.", result);
    }

    
    public void testPasswordMeetsComplexity() {
        // Test Data: "Ch&sec@ke99!"
        String result = login.registerUser("Kyle", "Smith", "kyl_1", "Ch&sec@ke99!", VALID_CELL);
        assertEquals("Username successfully captured. Password successfully captured. "
                + "Cell phone number successfully captured.", result);
    }

    
    public void testPasswordDoesNotMeetComplexity() {
        // Test Data: "password"
        String result = login.registerUser("Kyle", "Smith", "kyl_1", "password", VALID_CELL);
        assertEquals("Password is not correctly formatted; please ensure that the password "
                + "contains at least eight characters, a capital letter, a number, and a "
                + "special character.", result);
    }

    
    public void testCellPhoneNumberCorrectlyFormatted() {
        // Test Data: +27838968976
        String result = login.registerUser("Kyle", "Smith", "kyl_1", VALID_PASSWORD, "+27838968976");
        assertEquals("Username successfully captured. Password successfully captured. "
                + "Cell phone number successfully captured.", result);
    }

    
    public void testCellPhoneNumberIncorrectlyFormatted() {
        // Test Data: "08966553"
        String result = login.registerUser("Kyle", "Smith", "kyl_1", VALID_PASSWORD, "08966553");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an "
                + "international code; please correct the number and try again.", result);
    }

    //*** assertTrue/False ***

    
    public void testLoginSuccessful() {
        login.registerUser("Kyle", "Smith", "kyl_1", VALID_PASSWORD, VALID_CELL);
        boolean result = login.loginUser("kyl_1", VALID_PASSWORD);
        assertTrue(result, "Login should succeed with the credentials used at registration");
    }

    
    public void testLoginFailed() {
        login.registerUser("Kyle", "Smith", "kyl_1", VALID_PASSWORD, VALID_CELL);
        boolean result = login.loginUser("kyl_1", "wrongPassword1!");
        assertFalse(result, "Login should fail with an incorrect password");
    }

    
    public void testUsernameValid_returnsTrue() {
        boolean result = login.checkUserName("kyl_1");
        assertTrue(result, "Username with underscore and length <= 5 should be accepted");
    }

    
    public void testUsernameInvalid_returnsFalse() {
        boolean result = login.checkUserName("kyle!!!!!");
        assertFalse(result, "Username without underscore and over 5 characters should be rejected");
    }

    
    public void testPasswordValid_returnsTrue() {
        boolean result = login.checkPasswordComplexity("Ch&sec@ke99!");
        assertTrue(result, "Password that meets all complexity rules should be accepted");
    }

    
    public void testPasswordInvalid_returnsFalse() {
        boolean result = login.checkPasswordComplexity("password");
        assertFalse(result, "Simple password should be rejected");
    }

    
    public void testCellPhoneNumberValid_returnsTrue() {
        boolean result = login.checkCellPhoneNumber("+27838968976");
        assertTrue(result, "Correctly formatted SA cell number should be accepted");
    }

    
    public void testCellPhoneNumberInvalid_returnsFalse() {
        boolean result = login.checkCellPhoneNumber("08966553");
        assertFalse(result, "Cell number missing the +27 international code should be rejected");
    }


}
