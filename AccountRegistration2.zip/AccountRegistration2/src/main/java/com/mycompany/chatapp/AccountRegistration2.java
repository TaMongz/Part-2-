package com.mycompany.chatapp;

import java.util.Scanner;

/**
 * Simple console front-end for the registration/login feature,
 * extended with the QuickChat messaging feature (Part 2).
 */
public class AccountRegistration2 {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            Login login = new Login();
            boolean running = true;

            System.out.println("=== Welcome to the Chat App ===");

            while (running) {
                System.out.println("\n1. Register");
                System.out.println("2. Login");
                System.out.println("3. Exit");
                System.out.print("Choose an option: ");
                String choice = scanner.nextLine().trim();

                switch (choice) {
                    case "1" -> register(scanner, login);
                    case "2" -> login(scanner, login);
                    case "3" -> {
                        running = false;
                        System.out.println("Goodbye!");
                    }
                    default -> System.out.println("Invalid option, please choose 1, 2 or 3.");
                }
            }
        }
    }

    private static void register(Scanner scanner, Login login) {
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username (must contain '_' and be at most 5 characters): ");
        String username = scanner.nextLine();

        System.out.print("Enter password (8+ chars, capital letter, number, special character): ");
        String password = scanner.nextLine();

        System.out.print("Enter South African cell number (e.g. +27683213980): ");
        String cellPhoneNumber = scanner.nextLine();

        String result = login.registerUser(firstName, lastName, username, password, cellPhoneNumber);
        System.out.println(result);
    }

    private static void login(Scanner scanner, Login login) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        String result = login.returnLoginStatus(username, password);
        System.out.println(result);

        // ADJUST if your Login class words a successful login differently.
        if (result.toLowerCase().startsWith("welcome")) {
            chatMenu(scanner);
        }
    }

    
    private static void chatMenu(Scanner scanner) {
        System.out.println("\nWelcome to QuickChat.");
        boolean chatting = true;

        while (chatting) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> sendMessages(scanner);
                case "2" -> System.out.print(Message.printMessages());
                case "3" -> {
                    chatting = false;
                    System.out.println("Total messages sent: " + Message.returnTotalMessages());
                }
                default -> System.out.println("Invalid option, please choose 1, 2 or 3.");
            }
        }
    }

    private static void sendMessages(Scanner scanner) {
        int total = readPositiveInt(scanner, "How many messages would you like to enter? ");

        int done = 0;
        while (done < total) {
            System.out.print("Recipient cell number (e.g. +27718693002): ");
            String cell = scanner.nextLine().trim();

            System.out.print("Message (max 250 characters): ");
            String text = scanner.nextLine();

            if (text.trim().isEmpty()) {
                System.out.println("Message cannot be empty.");
                continue;
            }

            Message message = new Message(cell, text);
            System.out.println("Message ID generated: " + message.getMessageID());

            String lengthResult = message.checkMessageLength();
            String cellResult = message.checkRecipientCell();
            System.out.println(lengthResult);
            System.out.println(cellResult);

            if (!lengthResult.equals("Message ready to send.")
                    || !cellResult.equals("Cell phone number successfully captured.")) {
                continue; // re-enter this message
            }

            System.out.println("Message Hash: " + message.getMessageHash());
            System.out.println("1) Send Message  2) Disregard Message  3) Store Message");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            if (!choice.matches("[123]")) {
                System.out.println("Invalid option. Please try this message again.");
                continue;
            }

            System.out.println(message.SentMessage(Integer.parseInt(choice)));
            if (choice.equals("1")) {
                System.out.println(message.getDetails());
            }
            done++;
        }
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int n = Integer.parseInt(scanner.nextLine().trim());
                if (n > 0) return n;
            } catch (NumberFormatException ignored) { }
            System.out.println("Please enter a whole number greater than 0.");
        }
    }
}
