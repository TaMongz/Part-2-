package com.mycompany.chatapp;


public class Login {

    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhoneNumber;
    private boolean registered = false;

    /**
     * Checks that the username contains an underscore and is no more
     * than five characters long.
     * @param username
     * @return 
     */
    public boolean checkUserName(String username) {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    /**
     * Checks that the password is at least 8 characters long and
     * contains a capital letter, a number, and a special character.
     * @param password
     * @return 
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUpper = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }

        return hasUpper && hasDigit && hasSpecial;
    }
    
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        return cellPhoneNumber != null
                && cellPhoneNumber.matches("^\\+27\\d{9}$");
    }

    /**
     * Validates and registers a new user. Only stores the details and
     * marks the user as registered if ALL conditions are met.
     *
     * @param firstName
     * @param lastName
     * @param username
     * @param password
     * @param cellPhoneNumber
     * @return a message indicating success, or describing every
     *         validation failure found.
     */
    public String registerUser(String firstName, String lastName, String username,
                                String password, String cellPhoneNumber) {

        boolean usernameOk = checkUserName(username);
        boolean passwordOk = checkPasswordComplexity(password);
        boolean cellOk = checkCellPhoneNumber(cellPhoneNumber);

        StringBuilder message = new StringBuilder();

        if (!usernameOk) {
            message.append("""
                           Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.
                           """);
        }
        if (!passwordOk) {
        }
        if (!cellOk) {
        }

        if (usernameOk && passwordOk && cellOk) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.cellPhoneNumber = cellPhoneNumber;
            this.registered = true;
            return "Username successfully captured. Password successfully captured. "
                    + "Cell phone number successfully captured.";
        }

        return message.toString().trim();
    }

    /**
     * Verifies that the supplied username and password match the
     * credentials captured at registration.
     * @param username
     * @param password
     * @return 
     */
    public boolean loginUser(String username, String password) {
        return registered
                && this.username != null
                && this.password != null
                && this.username.equals(username)
                && this.password.equals(password);
    }

    /**
     * Returns the appropriate feedback message for a login attempt.
     * @param username
     * @param password
     * @return 
     */
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + firstName + ", " + lastName + ", it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }

    public boolean isRegistered() {
        return registered;
    }
}
