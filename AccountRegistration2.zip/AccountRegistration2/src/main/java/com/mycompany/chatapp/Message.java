package com.mycompany.chatapp;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {

    public static final int SEND = 1;
    public static final int DISREGARD = 2;
    public static final int STORE = 3;

    // Shared across the running program
    private static final List<Message> sentMessages = new ArrayList<>();
    private static int messagesCreated = 0;
    private static Path storageFile = Path.of("messages.json");

    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String text;
    private final String messageHash;

    /** Auto-generates the message ID and message number. */
    public Message(String recipient, String text) {
        this(generateID(), messagesCreated, recipient, text);
        messagesCreated++;
    }

    /** Used when the ID / number must be supplied (e.g. unit tests). */
    public Message(String messageID, int messageNumber, String recipient, String text) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.text = text;
        this.messageHash = createMessageHash();
    }

    private static String generateID() {
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) sb.append(r.nextInt(10));
        return sb.toString();
    }

     * @return  
    public boolean checkMessageID() {
        return messageID != null && !messageID.isEmpty() && messageID.length() <= 10;
    }
     * @return  
    public String checkMessageLength() {
        int length = text.length();
        if (length <= 250) {
            return "Message ready to send.";
        }
        return "Message exceeds 250 characters by " + (length - 250) + "; please reduce the size.";
    }

    
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+\\d{1,3}\\d{1,10}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.";
    }

    /** Format: first two ID digits : message number : FIRSTWORD+LASTWORD (upper case). */
    public String createMessageHash() {
        String[] words = text.trim().split("\\s+");
        String first = clean(words[0]);
        String last = clean(words[words.length - 1]);
        String prefix = messageID.length() >= 2 ? messageID.substring(0, 2) : messageID;
        return (prefix + ":" + messageNumber + ":" + first + last).toUpperCase();
    }

    private static String clean(String word) {
        return word.replaceAll("^\\W+|\\W+$", "");
    }

    /** choice: 1 = send, 2 = disregard, 3 = store. */
    public String SentMessage(int choice) {
        switch (choice) {
            case SEND:
                sentMessages.add(this);
                return "Message successfully sent.";
            case DISREGARD:
                return "Press 0 to delete the message.";
            case STORE:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option. Please choose 1 (Send), 2 (Disregard) or 3 (Store).";
        }
    }

    /** Returns details of every message sent while the program has been running. */
    public static String printMessages() {
        if (sentMessages.isEmpty()) return "No messages have been sent.";
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageID).append('\n')
              .append("Message Hash: ").append(m.messageHash).append('\n')
              .append("Recipient: ").append(m.recipient).append('\n')
              .append("Message: ").append(m.text).append("\n\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    /** Appends this message to a JSON array in the storage file. */
    public void storeMessage() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Type listType = new TypeToken<List<Message>>() {}.getType();
        try {
            List<Message> stored = new ArrayList<>();
            if (Files.exists(storageFile)) {
                List<Message> existing = gson.fromJson(Files.readString(storageFile), listType);
                if (existing != null) stored.addAll(existing);
            }
            stored.add(this);
            Files.writeString(storageFile, gson.toJson(stored));
        } catch (IOException e) {
            throw new RuntimeException("Could not store message: " + e.getMessage(), e);
        }
    }

    /** Details of this single message. */
    public String getDetails() {
        return "Message ID: " + messageID + "\n"
             + "Message Hash: " + messageHash + "\n"
             + "Recipient: " + recipient + "\n"
             + "Message: " + text;
    }

    // --- helpers (mainly for tests) ---
    public static void setStorageFile(Path path) { storageFile = path; }
    public static void clearSentMessages() { sentMessages.clear(); }

    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getText() { return text; }
    public String getMessageHash() { return messageHash; }
}
